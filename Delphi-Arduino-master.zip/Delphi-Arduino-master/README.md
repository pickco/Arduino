# Delphi-Arduino
Example for communicate Delphi with arduino via serial port (virtual COM port).

Need to install COM port component first.
